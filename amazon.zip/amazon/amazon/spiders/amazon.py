from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import AmazonItem

from time import sleep


API_KEY = ''

API_URL = "http://api.scraperapi.com/?api_key=%s&url=" % API_KEY

class AmazonSpider(CrawlSpider):

    name = "amazon"

    link = "https://www.amazon.com/"

    main_link  = "https://www.amazon.com/s?k=swap_product"

    names = ["brand","product_name","currency_symbol","currency_code","price","shipping_rate_and_condition","count_of_rating","count_of_answered_question",
            "product_dimension","dimension_standard_unit","item_weight","item_weight_standard_unit","shipping_weight","shipping_weight_standard_unit",
            "asin","best_seller_rank","rating"]  

    #start_urls = ["https://www.amazon.com/WD_Black-Drive-External-Compatible-WDBA2W0020BBK-WESN/dp/B07VMTNDMK/ref=sr_1_1_sspa?keywords=ps4&qid=1583326265&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyQ1pOT1NWMFRJR1VXJmVuY3J5cHRlZElkPUEwMTM0NDMyMk9BUlpUSktRTktQViZlbmNyeXB0ZWRBZElkPUEwOTE5ODU4SkFKWUNLTllYWTkwJndpZGdldE5hbWU9c3BfYXRmJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ=="]

    def __init__(self,product=None,*args, **kwargs):                    
        super(AmazonSpider, self).__init__(*args, **kwargs)   

        self.product = product

        if product:
            
            self.temp = self.main_link
            self.temp = self.temp.replace("swap_product",str(product))
          
    def start_requests(self):    

        yield Request(url = self.temp,callback=self.parse)

    def parse(self,response):

        links = response.css("span[data-component-type='s-product-image'] a::attr(href)").extract()

        for link in links:
            temp = self.link
            yield Request( self.link + link,callback=self.product_page)

    def product_page(self,response):

        product = AmazonItem()


        product["brand"] = self.get_brand(response)

        product["product_name"] = self.get_product_name(response)

        product["currency_symbol"] = self.get_currency_symbol(response)

        product["currency_code"] = self.get_currency_code(response)

        product["price"] = self.get_price(response)
        
        if not product["price"] == "None":
            product["price"] = product["price"][1:]

        product["shipping_rate_and_condition"] = self.get_shipping_rate_and_condition(response)

        if not product["shipping_rate_and_condition"] == "none":
            product["shipping_rate_and_condition"] = product["shipping_rate_and_condition"].replace("\n","")

        product["count_of_rating"] = self.get_count_of_rating(response)

        product["count_of_answered_question"] = self.get_count_of_answered_question(response)
        
        product["product_dimension"] = self.get_product_dimension(response)

        if product["product_dimension"]:
            product["product_dimension"] = product["product_dimension"].split(" ")
            product["product_dimension"] = product["product_dimension"][:len(product["product_dimension"])-1]
            product["product_dimension"] = " ".join(product["product_dimension"])

        product["dimension_standard_unit"] = self.get_dimension_standard_unit(response)

        product["item_weight"] = self.get_item_weight(response)

        if product["item_weight"]:
            product["item_weight"] = product["item_weight"].split(" ")
            product["item_weight"] = product["item_weight"][:len(product["item_weight"])-1]
            product["item_weight"] = " ".join(product["item_weight"])

        product["item_weight_standard_unit"] = self.get_item_weight_standard_unit(response)

        product["shipping_weight"] = self.get_shipping_weight(response)

        if product["shipping_weight"]:
            product["shipping_weight"] = product["shipping_weight"].split(" ")
            product["shipping_weight"] = product["shipping_weight"][:len(product["shipping_weight"])-1]
            product["shipping_weight"] = " ".join(product["shipping_weight"])

        product["shipping_weight_standard_unit"] = self.get_shipping_weight_standard_unit(response)

        if not product["shipping_weight_standard_unit"] == "None":

            product["shipping_weight"] = product["shipping_weight"].replace(product["shipping_weight_standard_unit"],"")

        product["asin"] = self.get_asin(response)

        product["best_seller_rank"] = self.get_best_seller_rank(response)

        product["rating"] =  self.get_rating_distribution(response,product)

        for name in self.names:
            if product[f"{name}"]:
                product[f"{name}"] = product[f"{name}"].replace("'","")

        yield product
    

    def get_brand(self,response):

        brand = response.css("#bylineInfo::text").extract_first()

        if brand:

            return brand
        else:
            brand = 'None'

    def get_product_name(self,response):

        brand = response.css("#productTitle::text").extract_first()

        if brand:

            return brand.strip()
        else:
            return 'None'

    def get_currency_symbol(self,response):

        # symbol =  self.get_price(response)

        # if symbol:
        #     return symbol[1]
        # else: 
        #     return "None"

        return "$"

    def get_currency_code(self,response):

        return 'USD' 

    def get_price(self,response):


        price = response.css("#price_inside_buybox::text").extract_first()

        if price:

            return price.strip()
        else:
            price = response.css("#priceblock_ourprice::text").extract_first()

            if price:

                return price.strip()
            else:
                return 'None'

    def get_shipping_rate_and_condition(self,response):

        price = response.css("#price-shipping-message span::text").extract_first()

        if price:
            return price.strip()
        else:
            price = response.css("#ourprice_shippingmessage span::text").extract_first()

            if price:
                return price.strip()
            else:
                return "None"

    def get_count_of_rating(self,response):

        count_rating = response.css("#acrCustomerReviewText::text").extract_first()

        if count_rating:
            temp = count_rating.split(" ")[0]

            return temp
        else:
            return "None"

    def get_count_of_answered_question(self,response):

        count = response.css("#askATFLink span::text").extract_first()

        if count:
            count = count.strip()
            temp = count.split(" ")[0]

            return temp
        else:
            return "None"
    
    def get_product_dimension(self,response):
        
        dimension = response.xpath('//th[contains(text(),"Product Dimensions")]/following-sibling::td/text()').extract_first()

        if dimension:
            dimension = dimension.strip()
            dimension = dimension.replace("\n","")
            return dimension
        else:
            return "None"

    def get_dimension_standard_unit(self,response):

        dimension = self.get_product_dimension(response)

        if dimension:
            dimension = dimension.split(" ")
            dimension = dimension[len(dimension) - 1]
            return dimension
        else:
            return "None"

    def get_item_weight(self,response):

        tem_weight = response.xpath('//th[contains(text(),"Item Weight")]/following-sibling::td/text()').extract_first()

        if tem_weight:
            tem_weight = tem_weight.strip()
            tem_weight = tem_weight.replace("\n","")
            return tem_weight
        else:
            return "None"

    def get_item_weight_standard_unit(self,response):

        unit = self.get_item_weight(response)

        if unit:
            unit = unit.split(" ")
            unit = unit[len(unit) - 1]
            return unit
        else:
            return "None"

    def get_shipping_weight(self,response):

        tem_weight = response.xpath('//th[contains(text(),"Shipping Weight")]/following-sibling::td/text()').extract_first()

        if tem_weight:
            tem_weight = tem_weight.strip()
            tem_weight = tem_weight.replace("\n","")
            return tem_weight
        else:
            return "None"

    def get_shipping_weight_standard_unit(self,response):

        unit = self.get_item_weight(response)

        if unit:
            unit = unit.split(" ")
            unit = unit[len(unit) - 1]
            return unit
        else:
            return "None"

    def get_asin(self,response):

        asin = response.xpath('//th[contains(text(),"ASIN")]/following-sibling::td/text()').extract_first()

        if asin:
            asin = asin.strip()
            asin = asin.replace("\n","")
            return asin
        else:
            return "None"

    def get_best_seller_rank(self,response):

        save =  response.xpath('//th[contains(text(),"Best Sellers Rank")]/following-sibling::td/span/span/text()').extract_first()
        
        if save:

            if "n" == save[len(save)-1]:
                second = response.xpath('//th[contains(text(),"Best Sellers Rank")]/following-sibling::td/span/span/a/text()').extract_first()

                save = save + second
        else:
            save = "None"

        return save

    def get_rating_distribution(self,response,product):
        
        rating = response.css(".a-icon.a-icon-star.a-star-5 span::text").extract_first()

        if rating:
            return rating
        else:
            return "None"

