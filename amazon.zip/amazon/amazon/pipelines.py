# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import sqlite3

class AmazonPipeline(object):
    def __init__(self,product):
        product = product.replace("+","_")

        self.create_connection(product)
        self.create_table(product)
        pass
    
    @classmethod
    def from_crawler(cls, crawler):
        return cls(product=crawler.spider.product)

    def create_connection(self,product):
        product = str(product)

        self.conn = sqlite3.Connection(f'{product}.db')
        self.curr = self.conn.cursor()
    
    def create_table(self,product):
        product = str(product)

        self.curr.execute(f"drop table if exists {product}_table")
        self.curr.execute(f"CREATE TABLE {product}_table( brand text,product_name text,currency_symbol text,currency_code text,price text, shipping_rate_and_condition text, count_of_rating text,count_of_answered_question text,product_dimension text,dimension_standard_unit text,item_weight text,item_weight_standard_unit text, shipping_weight text,shipping_weight_standard_unit text,asin text, best_seller_rank text,rating text)")

    def process_item(self, item, spider):

        self.store_db(item,spider.product)

        return item

    def store_db(self,item,product):

        product = str(product)
        product = product.replace("+","_")
        
        self.curr.execute(f"insert into {product}_table values ('{item['brand']}','{item['product_name']}','{item['currency_symbol']}','{item['currency_code']}','{item['price']}','{item['shipping_rate_and_condition']}','{item['count_of_rating']}','{item['count_of_answered_question']}','{item['product_dimension']}','{item['dimension_standard_unit']}','{item['item_weight']}','{item['item_weight_standard_unit']}','{item['shipping_weight']}','{item['shipping_weight_standard_unit']}','{item['asin']}','{item['best_seller_rank']}','{item['rating']}')")

        self.conn.commit()
