# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy import Field, Item

class AmazonItem(Item):

    brand = Field()
    product_name = Field()
    currency_symbol = Field()
    currency_code = Field()
    price = Field()
    shipping_rate_and_condition = Field()
    count_of_rating = Field()
    count_of_answered_question = Field()
    product_dimension = Field()
    dimension_standard_unit = Field()
    item_weight = Field()
    item_weight_standard_unit = Field()
    shipping_weight = Field()
    shipping_weight_standard_unit = Field()
    asin = Field()
    best_seller_rank = Field()
    rating = Field()


    pass
